const data = require("./math");
console.log(data.student[2]);
// console.log(data.cube(4));
